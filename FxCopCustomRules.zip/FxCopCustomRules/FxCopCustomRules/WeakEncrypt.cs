﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.FxCop.Sdk;
using Microsoft.VisualStudio.CodeAnalysis.Extensibility;

public class WeakEncryption : BaseRule
{
    public WeakEncryption()
        : base("WeakEncryption")
    {
    }
    public override ProblemCollection Check(TypeNode type)
    {
        if (type.Name.Name.Contains("System.Security.Cryptography.RC2") || type.Name.Name.Contains("System.Security.Cryptography.RC2.RC2CryptoServiceProvider") || type.Name.Name.Contains("System.Security.Cryptography.DES") || type.Name.Name.Contains("System.Security.Cryptography.DES.DESCryptoServiceProvider"))
        {
            var resolution = GetResolution(type.Name.Name);
            var problem = new Problem(resolution, type)
            {
                Certainty = 100,
                FixCategory = FixCategories.Breaking,
                MessageLevel = MessageLevel.Warning
            };
            Problems.Add(problem);
        }
        return Problems;
    }
    public override ProblemCollection Check(Member member)
    {

        Method method = member as Method;
        Instruction objInstr = null;
        // bool prob = false;
        if (method == null)
        {
            return null;
        }
        for (int i = 0; i < method.Instructions.Count; i++)
        {
            objInstr = method.Instructions[i];
            if (objInstr.Value != null)
            {
                if (objInstr.Value.ToString().Contains("System.Security.Cryptography.RC2") || objInstr.Value.ToString().Contains("System.Security.Cryptography.RC2.RC2CryptoServiceProvider") || objInstr.Value.ToString().Contains("System.Security.Cryptography.DES") || objInstr.Value.ToString().Contains("System.Security.Cryptography.DES.DESCryptoServiceProvider"))
                {
                    Resolution resolu = GetResolution(new string[] { method.ToString() });
                    Problems.Add(new Problem(resolu));
                }

            }
        }
        return Problems;

    }

}