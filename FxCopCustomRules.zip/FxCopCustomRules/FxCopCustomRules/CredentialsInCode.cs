﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.FxCop.Sdk;
using Microsoft.VisualStudio.CodeAnalysis.Extensibility;

namespace HardcodedPasswords
{
    public class CredentialsInCode : BaseRule
    {
        public Member member1;
        public Method method2;
        public CredentialsInCode() : base("CredentialsInCode")
        {
        }

        public override ProblemCollection Check(Member member)
        {

            if (ContainsUserOrPasswordInName(member.Name.Name.ToString()))
            {
                Type b = member.GetType();
                if (b.Equals(typeof(Microsoft.FxCop.Sdk.Field)))
                {
                    System.Console.WriteLine(member.Name.Name);
                    Resolution resolu = GetResolution(new string[] { member.Name.Name });
                    Problems.Add(new Problem(resolu, member.Name.Name));
                }
            }

            Method method = member as Method;

            if (method == null)
                return null;

            LocalCollection list = null;

            if (method.Instructions.Count > 0)
            {
                list = method.Instructions[0].Value as LocalCollection;
            }

            if (list != null)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    Local local = list[i];
                    if (ContainsUserOrPasswordInName(local.Name.Name.ToString()))
                    {
                        //System.Console.WriteLine(local.Name.Name.ToString());
                        Resolution resolu1 = GetResolution(local.Name.Name);
                        Problems.Add(new Problem(resolu1, local.Name.Name));
                    }
                }
            }
            return Problems;
        }

        private bool ContainsUserOrPasswordInName(string variableName)
        {
            variableName = variableName.ToLower();

            if (Regex.Match(variableName, @"(p|pass)(w|wrd|word)[\s]*",
             RegexOptions.IgnoreCase).Success)
            {
                return true;

            }
            if (Regex.Match(variableName, @"[\n\s]*(usern|userename|uname)[\s]*",
                RegexOptions.IgnoreCase).Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
