﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.FxCop.Sdk;
using Microsoft.VisualStudio.CodeAnalysis.Extensibility;

public class LogInjection : BaseRule
{
    public LogInjection() : base("LogInjection")
    {
    }

    public override ProblemCollection Check(TypeNode type)
    {
        if (type.Name.Name.Contains("ILog.Info") ||
    type.Name.Name.Contains("ILog.Debug") ||
    type.Name.Name.Contains("ILog.Error") ||
      type.Name.Name.Contains("ILog.Fatal") ||
           type.Name.Name.Contains("ILog.Warn") ||
             type.Name.Name.Contains("Logger.Write") ||
                 type.Name.Name.Contains("LogEntry.Message") ||
                    type.Name.Name.Contains("LogEntry.AppDomainName") ||
     type.Name.Name.Contains("LogEntry.MachineName") ||
                     type.Name.Name.Contains("LogEntry.ManagedThreadName") ||
                             type.Name.Name.Contains("LogEntry.ProcessId") ||
            type.Name.Name.Contains("LogEntry.ProcessName") ||
                     type.Name.Name.Contains("LogEntry.Title"))
        {
            var resolution = GetResolution(type.Name.Name);
            var problem = new Problem(resolution, type.Name.Name)
            {
                Certainty = 100,
                FixCategory = FixCategories.Breaking,
                MessageLevel = MessageLevel.Warning
            };
            Problems.Add(problem);
        }
        return Problems;
    }
    public override ProblemCollection Check(Member member)
    {

        Method method = member as Method;
        Instruction objInstr = null;
        if (method == null)
        {
            return null;
        }
        // bool prob = false;s
        int count = method.Instructions.Count;
        for (int i = 0; i < count; i++)
        {
            objInstr = method.Instructions[i];
            if (objInstr.Value != null)
            {
                if (objInstr.Value.ToString().Contains(".Info") ||
    objInstr.Value.ToString().Contains("ILog.Debug") ||
    objInstr.Value.ToString().Contains("ILog.Error") ||
      objInstr.Value.ToString().Contains("ILog.Fatal") ||
           objInstr.Value.ToString().Contains("ILog.Warn") ||
             objInstr.Value.ToString().Contains("Logger.Write") ||
                 objInstr.Value.ToString().Contains("LogEntry.Message") ||
                     objInstr.Value.ToString().Contains("LogEntry.AppDomainName") ||
     objInstr.Value.ToString().Contains("LogEntry.MachineName") ||
                     objInstr.Value.ToString().Contains("LogEntry.ManagedThreadName") ||
                             objInstr.Value.ToString().Contains("LogEntry.ProcessId") ||
             objInstr.Value.ToString().Contains("LogEntry.ProcessName") ||
                     objInstr.Value.ToString().Contains("LogEntry.Title"))
                {
                    //Local local = objInstr.Value as Local;
                    //Resolution resolu = GetResolution(local.Name.Name);
                    //Problems.Add(new Problem(resolu,local.Name.Name));
                    Resolution resolu = GetResolution(method.Name.Name);
                    Problems.Add(new Problem(resolu, method.Name.Name));
                }

            }
        }
        return Problems;

    }

}