﻿using Microsoft.FxCop.Sdk;
using Microsoft.VisualStudio.CodeAnalysis.Extensibility;
using System;
using System.Collections.Generic;
using System.Text;

public class InsecureRandom : BaseRule
{
    public InsecureRandom()
        : base("InsecureRandom")
    {
    }
    public override ProblemCollection Check(Member member)
    {

        Method method = member as Method;
        if (method == null)
        {
            return Problems;
        }
        Instruction objInstr = null;
        // bool prob = false;
        for (int i = 0; i < method.Instructions.Count; i++)
        {
            objInstr = method.Instructions[i];
            if (objInstr.Value != null)
            {
                if (objInstr.Value.ToString().Contains("System.Random"))
                {

                    Resolution resolu = GetResolution(new string[] { method.ToString() });
                    Problems.Add(new Problem(resolu));
                }

            }
        }
        return Problems;

    }

}