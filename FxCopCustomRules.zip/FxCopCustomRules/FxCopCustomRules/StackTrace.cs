﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.FxCop.Sdk;
using Microsoft.VisualStudio.CodeAnalysis.Extensibility;

public class StackTrace : BaseRule
{
    public StackTrace() : base("StackTrace")
    {
    }

    public override ProblemCollection Check(Member member)
    {

        Method method = member as Method;
        Instruction objInstr = null;
        if (method == null)
        {
            return Problems;
        }
        // bool prob = false;s
        int count = method.Instructions.Count;
        for (int i = 0; i < count; i++)
        {
            objInstr = method.Instructions[i];
            if (objInstr.Value != null)
            {
                if (objInstr.Value.ToString().Contains("System.Exception"))
                {
                    if (objInstr.Value.ToString().Contains("StackTrace"))
                    {
                        Resolution resolu = GetResolution(method.Name.Name);
                        Problems.Add(new Problem(resolu, method.Name.Name));
                    }
                }

            }
        }
        return Problems;

    }

}