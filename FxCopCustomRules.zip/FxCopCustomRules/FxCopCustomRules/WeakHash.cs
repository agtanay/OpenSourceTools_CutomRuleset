﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.FxCop.Sdk;
using Microsoft.VisualStudio.CodeAnalysis.Extensibility;

public class WeakHash : BaseRule
{
    public WeakHash()
        : base("WeakHash")
    {
    }

    public override ProblemCollection Check(TypeNode type)
    {
        if (type.Name.Name.Contains("System.Security.Cryptography.MD5") || type.Name.Name.Contains("System.Security.Cryptography.SHA!"))
        {
            var resolution = GetResolution(type.Name.Name);
            var problem = new Problem(resolution, type)
            {
                Certainty = 100,
                FixCategory = FixCategories.Breaking,
                MessageLevel = MessageLevel.Warning
            };
            Problems.Add(problem);
        }
        return Problems;
    }
    public override ProblemCollection Check(Member member)
    {
        if (member.Name.Name.ToString().Contains("System.Security.Cryptography.MD5") || member.Name.Name.ToString().Contains("System.Security.Cryptography.SHA1"))
        {
            Resolution resolu = GetResolution(new string[] { member.Name.Name });
            Problems.Add(new Problem(resolu, member.Name.Name));
        }
        Method method = member as Method;
        Instruction objInstr = null;
        // bool prob = false;

        if (method == null)
        {
            return null;
        }
        for (int i = 0; i < method.Instructions.Count; i++)
        {
            objInstr = method.Instructions[i];
            if (objInstr.Value != null)
            {
                if (objInstr.Value.ToString().Contains("System.Security.Cryptography.MD5") || objInstr.Value.ToString().Contains("System.Security.Cryptography.SHA1"))
                {
                    Resolution resolu = GetResolution(new string[] { method.ToString() });
                    Problems.Add(new Problem(resolu));
                }

            }
        }
        return Problems;

    }

}