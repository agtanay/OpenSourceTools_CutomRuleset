﻿using Microsoft.FxCop.Sdk;
using Microsoft.VisualStudio.CodeAnalysis.Extensibility;
using System;
using System.Collections.Generic;
using System.Text;

public class Connectionclosed : BaseRule
{
    public Connectionclosed()
        : base("Connectionclosed")
    {
    }
    public override ProblemCollection Check(Member member)
    {

        Method method = member as Method;
        Instruction objInstr = null;
        // bool prob = false;
        if (method == null)
        {
            return null;
        }
        for (int i = 0; i < method.Instructions.Count; i++)
        {
            objInstr = method.Instructions[i];
            if (objInstr.Value != null)
            {
                if (objInstr.Value.ToString().Contains("OdbcConnection.Close") ||
                    objInstr.Value.ToString().Contains("OleDbConnection.Close") ||
                    objInstr.Value.ToString().Contains("OracleConnection.Close") ||
                    objInstr.Value.ToString().Contains("BinaryReader.Close") ||
                    objInstr.Value.ToString().Contains("BinaryWriter.Close") ||
                    objInstr.Value.ToString().Contains("StreamReader.Close") ||
                    objInstr.Value.ToString().Contains("StreamWriter.Close") ||
                    objInstr.Value.ToString().Contains("StringReader.Close") ||
                    objInstr.Value.ToString().Contains("StringWriter.Close") ||
                    objInstr.Value.ToString().Contains("TextWriter.Close") ||
                    objInstr.Value.ToString().Contains("TextReader.Close") ||
                    objInstr.Value.ToString().Contains("FileStream.Close") ||
                    objInstr.Value.ToString().Contains("Stream.Close") ||
                    objInstr.Value.ToString().Contains("MemoryStream.Close") ||
                    objInstr.Value.ToString().Contains("UnmanagedMemoryStream.Close") || objInstr.Value.ToString().Contains("BufferedStream.Close") ||
                    
                    objInstr.Value.ToString().Contains("OdbcConnection.Dispose") ||
                    objInstr.Value.ToString().Contains("OleDbConnection.Dispose") ||
                    objInstr.Value.ToString().Contains("OracleConnection.Dispose") ||
                    objInstr.Value.ToString().Contains("BinaryReader.Dispose") ||
                    objInstr.Value.ToString().Contains("BinaryWriter.Dispose") ||
                    objInstr.Value.ToString().Contains("StreamReader.Dispose") ||
                    objInstr.Value.ToString().Contains("StreamWriter.Dispose") ||
                    objInstr.Value.ToString().Contains("StringReader.Dispose") ||
                    objInstr.Value.ToString().Contains("StringWriter.Dispose") ||
                    objInstr.Value.ToString().Contains("SqlConnection.Close") ||
                    objInstr.Value.ToString().Contains("TextWriter.Dispose") ||
                    objInstr.Value.ToString().Contains("TextReader.Dispose") ||
                    objInstr.Value.ToString().Contains("FileStream.Dispose") ||
                    objInstr.Value.ToString().Contains("Stream.Dispose") ||
                    objInstr.Value.ToString().Contains("MemoryStream.Dispose") ||
                    objInstr.Value.ToString().Contains("UnmanagedMemoryStream.Dispose") || objInstr.Value.ToString().Contains("BufferedStream.Dispose") 
                    )
                {

                    Resolution resolu = GetResolution(new string[] { method.Name.Name.ToString() });
                    Problems.Add(new Problem(resolu));
                }

            }
        }
        return Problems;

    }

}