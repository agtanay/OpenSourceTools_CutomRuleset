﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.FxCop.Sdk;
using Microsoft.VisualStudio.CodeAnalysis.Extensibility;
using System.Web;


public class AuthByHostname : BaseRule
{
    public AuthByHostname() : base("AuthByHostname")
    {
    }

    public override ProblemCollection Check(TypeNode type)
    {
        if (type.Name.Name.Contains("System.Environment") || type.Name.Name.Contains("Current.Server"))
        {
            if (type.Name.Name.Contains("MachineName"))
            {
                var resolution = GetResolution(type.Name.Name);
                var problem = new Problem(resolution, type.Name.Name)
                {
                    Certainty = 100,
                    FixCategory = FixCategories.Breaking,
                    MessageLevel = MessageLevel.Warning
                };
                Problems.Add(problem);
            }
        }
        else if (type.Name.Name.Contains("Dns.GetHostName"))
        {
            var resolution = GetResolution(type.Name.Name);
            var problem = new Problem(resolution, type.Name.Name)
            {
                Certainty = 100,
                FixCategory = FixCategories.Breaking,
                MessageLevel = MessageLevel.Warning
            };
            Problems.Add(problem);
        }
        return Problems;
    }
    public override ProblemCollection Check(Member member)
    {

        Method method = member as Method;
        Instruction objInstr = null;

        if (method == null)
        {
            return null;
        }
        // bool prob = false;s
        int count = method.Instructions.Count;
        for (int i = 0; i < count; i++)
        {
            objInstr = method.Instructions[i];
            if (objInstr.Value != null)
            {
                if (objInstr.Value.ToString().Contains("System.Environment") || objInstr.Value.ToString().Contains("Current.Server"))// || objInstr.Value.ToString().Contains("Path"))
                {
                    if (objInstr.Value.ToString().Contains("MachineName"))
                    {
                        // if (objInstr.Value.ToString().Contains("False"))
                        {
                            Resolution resolu = GetResolution(method.Name.Name);
                            Problems.Add(new Problem(resolu, method.Name.Name));
                        }
                    }
                }
                else if (objInstr.Value.ToString().Contains("Dns.GetHostName"))
                {
                    Resolution resolu = GetResolution(method.Name.Name);
                    Problems.Add(new Problem(resolu, method.Name.Name));
                }

            }
        }
        return Problems;

    }

}

