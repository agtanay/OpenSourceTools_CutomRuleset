﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.FxCop.Sdk;
using Microsoft.VisualStudio.CodeAnalysis.Extensibility;

public class CommandInjection : BaseRule
{
    public CommandInjection()
        : base("CommandInjection")
    {
    }

    
    public override ProblemCollection Check(Member member)
    {
        if (member.Name.Name.ToString().Contains("System.Diagnostics.Process") || member.Name.Name.ToString().Contains("Process.Start"))
        {
            Resolution resolu = GetResolution(new string[] { member.Name.Name });
            Problems.Add(new Problem(resolu, member.Name.Name));
            return Problems;
        }
        Method method = member as Method;
        Instruction objInstr = null;
        // bool prob = false;

        if(method == null)
        {
            return null;
        }
        for (int i = 0; i < method.Instructions.Count; i++)
        {
            objInstr = method.Instructions[i];
            if (objInstr.Value != null)
            {
                if (objInstr.Value.ToString().Contains("System.Diagnostics.Process") || objInstr.Value.ToString().Contains("Process.Start"))
                {
                    Resolution resolu = GetResolution(new string[] { method.ToString() });
                    Problems.Add(new Problem(resolu));
                }

            }
        }
        return Problems;

    }

}