﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.FxCop.Sdk;
using Microsoft.VisualStudio.CodeAnalysis.Extensibility;

public class XpathInjection : BaseRule
{
    public XpathInjection()
        : base("XpathInjection")
    {
    }


    public override ProblemCollection Check(Member member)
    {
        if (member.Name.Name.ToString().Contains("System.Xml.XmlDocument") || member.Name.Name.ToString().Contains("System.Xml.XPath.XPathNavigator"))
        {
            Resolution resolu = GetResolution(new string[] { member.Name.Name });
            Problems.Add(new Problem(resolu, member.Name.Name));
        }
        Method method = member as Method;
        Instruction objInstr = null;
        // bool prob = false;
        if (method == null)
        {
            return null;
        }
        for (int i = 0; i < method.Instructions.Count; i++)
        {
            objInstr = method.Instructions[i];
            if (objInstr.Value != null)
            {
                if (objInstr.Value.ToString().Contains("System.Xml.XmlDocument") || objInstr.Value.ToString().Contains("System.Xml.XPath.XPathNavigator"))
                {
                    Resolution resolu = GetResolution(new string[] { method.ToString() });
                    Problems.Add(new Problem(resolu));
                }

            }
        }
        return Problems;

    }

}