﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.FxCop.Sdk;
using Microsoft.VisualStudio.CodeAnalysis.Extensibility;

public class WeakInputValidation : BaseRule
{
    public WeakInputValidation()
        : base("WeakInputValidation")
    {
    }

    public override ProblemCollection Check(Member member)
    {

        Method method = member as Method;
        Instruction objInstr = null;
        // bool prob = false;
        if (method == null)
        {
            return Problems;
        }
        for (int i = 0; i < method.Instructions.Count; i++)
        {
            objInstr = method.Instructions[i];
            if (objInstr.Value != null)
            {
                if (objInstr.Value.ToString().Contains("Request.QueryString") || objInstr.Value.ToString().Contains("Request.Forms") || objInstr.Value.ToString().Contains("Request.Cookies"))
                {
                    Resolution resolu = GetResolution(new string[] { method.ToString() });
                    Problems.Add(new Problem(resolu));
                }

            }
        }
        return Problems;

    }

}