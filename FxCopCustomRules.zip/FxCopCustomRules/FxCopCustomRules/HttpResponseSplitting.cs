﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.FxCop.Sdk;
using Microsoft.VisualStudio.CodeAnalysis.Extensibility;

public class HttpResponseSplitting : BaseRule
{
    public HttpResponseSplitting()
        : base("HttpResponseSplitting")
    {
    }
    public override ProblemCollection Check(TypeNode type)
    {
        if (type.Name.Name.Contains("HttpResponse.AppendHeader") || type.Name.Name.Contains("HttpResponse.AddHeader"))
        {
            var resolution = GetResolution(type.Name.Name);
            var problem = new Problem(resolution, type)
            {
                Certainty = 100,
                FixCategory = FixCategories.Breaking,
                MessageLevel = MessageLevel.Warning
            };
            Problems.Add(problem);
        }
        return Problems;
    }
    public override ProblemCollection Check(Member member)
    {

        Method method = member as Method;
        Instruction objInstr = null;
        if (method == null)
        {
            return null;
        }
        // bool prob = false;
        for (int i = 0; i < method.Instructions.Count; i++)
        {
            objInstr = method.Instructions[i];
            if (objInstr.Value != null)
            {
                if (objInstr.Value.ToString().Contains("HttpResponse.AddHeader") || objInstr.Value.ToString().Contains("HttpResponse.AppendHeader"))
                {
                    Resolution resolu = GetResolution(new string[] { method.ToString() });
                    Problems.Add(new Problem(resolu, method.Name.Name));
                }

            }
        }
        return Problems;
    }
}
