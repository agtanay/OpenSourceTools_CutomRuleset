﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.FxCop.Sdk;
using Microsoft.VisualStudio.CodeAnalysis.Extensibility;
using System.Web;

public class SecureNotSet : BaseRule
{
    public SecureNotSet() : base("SecureNotSet")
    {
    }

    public override ProblemCollection Check(TypeNode type)
    {
        if (type.Name.Name.Contains("Secure"))// || type.Name.Name.Contains(".SetAuthCookie") || type.Name.Name.Contains(".Path"))
        {

            var resolution = GetResolution(type.Name.Name);
            var problem = new Problem(resolution, type.Name.Name)
            {
                Certainty = 100,
                FixCategory = FixCategories.Breaking,
                MessageLevel = MessageLevel.Warning
            };
            Problems.Add(problem);
        }
        return Problems;
    }
    public override ProblemCollection Check(Member member)
    {

        Method method = member as Method;
        Instruction objInstr = null;
        HttpCookie cookie = new HttpCookie("");
        if (method == null)
        {
            return null;
        }
        // bool prob = false;s
        int count = method.Instructions.Count;
        for (int i = 0; i < count; i++)
        {
            objInstr = method.Instructions[i];
            if (objInstr.Value != null)
            {
                if (objInstr.Value.ToString().Contains("Web.HttpCookie"))// || objInstr.Value.ToString().Contains("SetAuthCookie") || objInstr.Value.ToString().Contains("Path"))
                {
                    if (objInstr.Value.ToString().Contains("Secure"))
                    {
                        // if (objInstr.Value.ToString().Contains("False"))
                        {
                            Resolution resolu = GetResolution(method.Name.Name);
                            Problems.Add(new Problem(resolu, method.Name.Name));
                        }
                    }
                }

            }
        }
        return Problems;

    }

}